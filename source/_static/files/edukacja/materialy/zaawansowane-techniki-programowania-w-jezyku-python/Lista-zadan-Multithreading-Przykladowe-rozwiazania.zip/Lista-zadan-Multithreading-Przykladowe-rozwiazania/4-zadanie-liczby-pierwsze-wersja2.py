from concurrent.futures import ThreadPoolExecutor


def czy_pierwsza(x):
    if x <= 1:
        return False

    for i in range(2, x):
        if x % i == 0:
            return False

    return True


assert czy_pierwsza(0) is False
assert czy_pierwsza(1) is False
assert czy_pierwsza(2) is True
assert czy_pierwsza(3) is True
assert czy_pierwsza(4) is False
assert czy_pierwsza(5) is True
assert czy_pierwsza(6) is False
assert czy_pierwsza(7) is True
assert czy_pierwsza(8) is False
assert czy_pierwsza(9) is False
assert czy_pierwsza(10) is False
assert czy_pierwsza(11) is True
assert czy_pierwsza(12) is False
assert czy_pierwsza(97) is True
assert czy_pierwsza(100) is False


def main():
    ile_liczb = int(input("Ile liczb: "))
    liczby = []
    for _ in range(ile_liczb):
        liczby.append(int(input()))

    with ThreadPoolExecutor(max_workers=2) as executor:
        wyniki = list(executor.map(czy_pierwsza, liczby))

    for liczba, wynik in zip(liczby, wyniki):
        if wynik:
            print(f"Liczba {liczba} jest pierwsza")
        else:
            print(f"Liczba {liczba} nie jest pierwsza")


if __name__ == "__main__":
    main()
