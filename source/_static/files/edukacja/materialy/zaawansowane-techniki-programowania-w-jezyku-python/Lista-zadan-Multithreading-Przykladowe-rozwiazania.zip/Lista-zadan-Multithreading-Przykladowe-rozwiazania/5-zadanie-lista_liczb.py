from threading import Thread, Lock
import time


def count(x, results, results_lock):
    results_lock.acquire()

    for i in range(0, 9):
        wartosc = i + x * 10
        print(f"Watek {x}, wartosc: {wartosc}")
        results.append(wartosc)
        time.sleep(x)

    results_lock.release()


def main():
    results = []
    results_lock = Lock()

    threads = [
        Thread(target=count, args=(0, results, results_lock)),
        Thread(target=count, args=(1, results, results_lock)),
        Thread(target=count, args=(2, results, results_lock)),
        Thread(target=count, args=(3, results, results_lock)),
    ]

    for t in threads:
        t.start()

    for t in threads:
        t.join()

    print(results)


if __name__ == "__main__":
    main()
