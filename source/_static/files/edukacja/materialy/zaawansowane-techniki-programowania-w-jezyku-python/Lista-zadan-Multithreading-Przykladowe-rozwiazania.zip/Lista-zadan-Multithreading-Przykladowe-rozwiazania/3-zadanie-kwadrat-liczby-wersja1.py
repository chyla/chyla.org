# zadanie 3 - przykladowe rozwiazanie
# wersja 1 --> threading.Thread

import threading
import time


def kwadrat(x):
    return x * x


def liczenie_kwadratow(dane_wejsciowe, dane_wyjsciowe, poczatek, koniec):
    for i in range(poczatek, koniec):
        dane_wyjsciowe[i] = kwadrat(dane_wejsciowe[i])
        # print(dane_wyjsciowe[i])
        # time.sleep(1)


def main():
    linia_z_liczbami = input("Podaj liczby: ")
    # list comprehension
    liczby = [int(x) for x in linia_z_liczbami.split()]

    # odpowiednik:
    # liczby = []
    # for x in linia_z_liczbami.split():  # "a b c" --> ["a", "b", "c"]
    #     value = int(x)
    #     liczby.append(value)

    wyniki = [0] * len(liczby)

    t1 = threading.Thread(
        target=liczenie_kwadratow, args=(liczby, wyniki, 0, len(liczby) // 2)
    )
    t2 = threading.Thread(
        target=liczenie_kwadratow,
        args=(liczby, wyniki, len(liczby) // 2, len(liczby)),
    )

    t1.start()
    t2.start()

    t1.join()
    t2.join()

    print("Wyniki: ", end="")
    for x in wyniki:
        print(x, end=" ")
    print()


if __name__ == "__main__":
    main()
