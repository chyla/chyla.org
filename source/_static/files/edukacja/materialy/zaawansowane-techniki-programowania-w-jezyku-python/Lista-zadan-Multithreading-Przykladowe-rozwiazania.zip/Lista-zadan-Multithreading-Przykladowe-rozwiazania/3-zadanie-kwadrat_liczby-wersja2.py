# zadanie 3 - przykladowe rozwiazanie
# wersja 2 --> ThreadPoolExecutor
from concurrent.futures import ThreadPoolExecutor


def kwadrat(x):
    return x * x


def main():
    linia_z_liczbami = input("Podaj liczby: ")
    # list comprehension
    liczby = [int(x) for x in linia_z_liczbami.split()]

    with ThreadPoolExecutor(max_workers=2) as executor:
        wyniki = list(executor.map(kwadrat, liczby))

    print("Wyniki: ", end="")
    for x in wyniki:
        print(x, end=" ")
    print()


if __name__ == "__main__":
    main()
