import threading


def czy_pierwsza(x):
    if x <= 1:
        return False

    for i in range(2, x):
        if x % i == 0:
            return False

    return True


assert czy_pierwsza(0) is False
assert czy_pierwsza(1) is False
assert czy_pierwsza(2) is True
assert czy_pierwsza(3) is True
assert czy_pierwsza(4) is False
assert czy_pierwsza(5) is True
assert czy_pierwsza(6) is False
assert czy_pierwsza(7) is True
assert czy_pierwsza(8) is False
assert czy_pierwsza(9) is False
assert czy_pierwsza(10) is False
assert czy_pierwsza(11) is True
assert czy_pierwsza(12) is False
assert czy_pierwsza(97) is True
assert czy_pierwsza(100) is False


def sprawdzanie_pierwszosci(dane_wejsciowe, dane_wyjsciowe, od, do):
    for i in range(od, do):
        dane_wyjsciowe[i] = czy_pierwsza(dane_wejsciowe[i])


def main():
    ile_liczb = int(input("Ile liczb: "))
    liczby = []
    for _ in range(ile_liczb):
        liczby.append(int(input()))

    wyniki = [0] * len(liczby)

    t1 = threading.Thread(
        target=sprawdzanie_pierwszosci,
        args=(liczby, wyniki, 0, len(liczby) // 2),
    )
    t2 = threading.Thread(
        target=sprawdzanie_pierwszosci,
        args=(liczby, wyniki, len(liczby) // 2, len(liczby)),
    )

    t1.start()
    t2.start()

    t1.join()
    t2.join()

    for liczba, wynik in zip(liczby, wyniki):
        if wynik:
            print(f"Liczba {liczba} jest pierwsza")
        else:
            print(f"Liczba {liczba} nie jest pierwsza")


if __name__ == "__main__":
    main()
