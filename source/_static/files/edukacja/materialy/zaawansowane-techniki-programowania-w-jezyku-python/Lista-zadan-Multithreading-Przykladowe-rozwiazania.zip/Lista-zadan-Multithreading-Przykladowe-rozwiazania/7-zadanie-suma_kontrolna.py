from uuid import uuid4
from concurrent.futures import ThreadPoolExecutor
from hashlib import md5


def calculate_hash(uuid_hex):
    return md5(uuid_hex.encode()).hexdigest()


def main():
    uuids = [uuid4().hex for _ in range(200)]

    with ThreadPoolExecutor() as executor:
        results = executor.map(calculate_hash, uuids)

    for uuid, hash in zip(uuids, results):
        print(f"{uuid} - {hash}")


if __name__ == "__main__":
    main()
