def accumulate(it): # it - obiekt iterowalny
    suma = None
    for v in it:
        if suma is None:
            suma = v
        else:
            suma = suma + v

        yield suma

for x in accumulate([1, 2, 3, 4, 5]): # --> 1 3 6 10 15
    print(x)

for x in accumulate(['ala ', 'ma', ' kota']):
    print(x)
