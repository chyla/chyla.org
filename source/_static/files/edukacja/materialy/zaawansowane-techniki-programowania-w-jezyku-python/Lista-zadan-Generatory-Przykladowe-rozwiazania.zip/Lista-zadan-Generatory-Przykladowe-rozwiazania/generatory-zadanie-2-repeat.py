def repeat(value, times):
    for _ in range(0, times):
        yield value


for i in repeat(10, 5):
    print("repeat:", i)
