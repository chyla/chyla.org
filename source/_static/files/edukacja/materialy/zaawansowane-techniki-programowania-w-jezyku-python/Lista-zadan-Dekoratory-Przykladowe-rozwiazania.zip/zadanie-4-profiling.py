from functools import wraps
from datetime import datetime


def profile(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        start_at = datetime.now()
        ret = f(*args, **kwargs)
        end_at = datetime.now()
        print(f"DEBUG: {f.__name__} function execution took: {end_at - start_at}")
        return ret

    return wrapper


@profile
def first_function():
    return 1


@profile
def second_function(a, b, c):
    return a + b + c


@profile
def third_function(*args, **kwargs):
    return args[0] + args[1] + kwargs["c"]


def main():
    x = first_function()
    print("returned =", x)

    x = second_function(1, 2, 3)
    print("returned =", x)

    x = third_function(1, 2, c=3)
    print("returned =", x)


if __name__ == "__main__":
    main()
