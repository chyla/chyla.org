from functools import wraps


def debug_name(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        print(f"DEBUG: {f.__name__} function called")
        return f(*args, **kwargs)

    return wrapper


@debug_name
def first_function():
    return 1


@debug_name
def second_function(a, b, c):
    return a + b + c


@debug_name
def third_function(*args, **kwargs):
    return args[0] + args[1] + kwargs["c"]


def main():
    x = first_function()
    print("returned =", x)

    x = second_function(1, 2, 3)
    print("returned =", x)

    x = third_function(1, 2, c=3)
    print("returned =", x)


if __name__ == "__main__":
    main()
