from functools import wraps


def debug_name(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        msg_begin = f"DEBUG: {f.__name__} function called"

        print(msg_begin, f"with {len(args)} args:")
        for i, val in enumerate(args):
            print(msg_begin, f" <arg{i}> = {val}")

        print(msg_begin, f"with {len(kwargs)} kwargs:")
        for name, val in kwargs.items():
            print(msg_begin, f" {name} = {val}")

        ret = f(*args, **kwargs)

        print(msg_begin, "returned value:", ret)
        return ret

    return wrapper


@debug_name
def first_function():
    return 1


@debug_name
def second_function(a, b, c):
    return a + b + c


@debug_name
def third_function(*args, **kwargs):
    return args[0] + args[1] + kwargs["c"]


def main():
    x = first_function()
    print("returned =", x)

    x = second_function(1, 2, 3)
    print("returned =", x)

    x = third_function(1, 2, c=3)
    print("returned =", x)


if __name__ == "__main__":
    main()
