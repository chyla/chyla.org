# from fibbonacci import fibonacci, fibonacci_rekurencyjnie
# używamy funkcji w 'zwykły' sposób:
# fibonacci(x, cache=cache)


import fibonacci as fib
# używamy funkcji podając nazwę modułu
# fib.fibonacci(x, cache=cache)

import os


def odczytaj_cache_z_pliku(nazwa_pliku):
    cache = {}

    # sprawdzamy czy plik istnieje
    if os.path.exists(nazwa_pliku):
        # otwieramy plik
        with open(nazwa_pliku) as f:
            # odczytujemy linia po linii
            for linia in f:
                '''
                Funkcja split() dzieli napis na listę wyrazów według podanego
                w nawiasach separatora - domyslnie białe znaki.

                Przykład:
                'A B'.split()   -->  ['A', 'B']

                Elementy listy można przypisać do nazw:
                a, b = ['A', 'B']   --> a = 'A'  b = 'B'
                '''
                klucz, wartosc = linia.split("=")

                cache[int(klucz)] = int(wartosc)

    return cache


def zapisz_cache_do_pliku(cache, nazwa_pliku):
    # skłownik: { NUMER_WYRAZU : WARTOSC_WYRAZU }
    # zawartość pliku:
    # NUMER_WYRAZU=WARTOSC_WYRAZU
    # NUMER_WYRAZU=WARTOSC_WYRAZU
    # NUMER_WYRAZU=WARTOSC_WYRAZU
    # NUMER_WYRAZU=WARTOSC_WYRAZU

    with open(nazwa_pliku, "w") as f:
        for klucz, wartosc in cache.items():
            linia = "{}={}\n".format(klucz, wartosc)
            f.write(linia)


def main():
    # wczytanie cache z pliku
    cache = odczytaj_cache_z_pliku("fib-cache.txt")

    print("odczytany cache:", cache)

    x = int(input("Podaj numer elementu: "))

    wyraz = fib.fibonacci(x, cache=cache)
    print(wyraz)

    wyraz = fib.fibonacci_rekurencyjnie(x, cache=cache)
    print(wyraz)

    # zapisanie cache do pliku
    zapisz_cache_do_pliku(cache, "fib-cache.txt")


if __name__ == '__main__':
    main()
