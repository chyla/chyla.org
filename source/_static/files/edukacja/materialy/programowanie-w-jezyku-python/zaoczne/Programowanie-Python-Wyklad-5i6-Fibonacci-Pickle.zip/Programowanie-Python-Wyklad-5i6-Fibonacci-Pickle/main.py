# from fibbonacci import fibonacci, fibonacci_rekurencyjnie
# używamy funkcji w 'zwykły' sposób:
# fibonacci(x, cache=cache)

import pickle
import os.path

import fibonacci as fib

# używamy funkcji podając nazwę modułu
# fib.fibonacci(x, cache=cache)


def odczytaj_cache_z_pliku(nazwa_pliku):
    cache = {}

    if os.path.exists(nazwa_pliku):
        with open(nazwa_pliku, "rb") as f:
            cache = pickle.load(f)

    return cache


def zapisz_cache_do_pliku(cache, nazwa_pliku):
    # { NUMER_WYRAZU : WARTOSC_WYRAZU }
    # NUMER_WYRAZU=WARTOSC_WYRAZU
    # NUMER_WYRAZU=WARTOSC_WYRAZU
    # NUMER_WYRAZU=WARTOSC_WYRAZU
    # NUMER_WYRAZU=WARTOSC_WYRAZU

    with open(nazwa_pliku, "bw") as f:
        pickle.dump(cache, f, protocol=0)


def main():
    # wczytanie cache z pliku
    cache = odczytaj_cache_z_pliku("fib-cache.txt")

    print("odczytany cache:", cache)

    x = int(input("Podaj numer elementu: "))

    wyraz = fib.fibonacci(x, cache=cache)
    print(wyraz)

    wyraz = fib.fibonacci_rekurencyjnie(x, cache=cache)
    print(wyraz)

    # zapisanie cache do pliku
    zapisz_cache_do_pliku(cache, "fib-cache.txt")


if __name__ == '__main__':
    main()
