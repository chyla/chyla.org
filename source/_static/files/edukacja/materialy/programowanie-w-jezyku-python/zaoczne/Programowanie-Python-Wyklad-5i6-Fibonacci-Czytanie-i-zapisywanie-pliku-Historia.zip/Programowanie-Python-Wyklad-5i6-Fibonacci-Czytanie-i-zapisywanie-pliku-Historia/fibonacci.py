def sprawdz(wynik, oczekiwany):
    assert wynik == oczekiwany, (
        "Oczekiwano: " + str(oczekiwany) + "; otrzymano " + str(wynik)
    )


# def fibonacci(n):
#     if n < 0:
#         return None
#
#     if n == 0:
#         return 0
#
#     if n == 1:
#         return 1
#
#     return (fibonacci(n - 1)
#             + fibonacci(n - 2))


def fibonacci(n):
    if n < 0:
        return None

    wyrazy = [0, 1]

    for _ in range(0, n):
        kolejny_wyraz = sum(wyrazy)
        wyrazy.append(kolejny_wyraz)
        del wyrazy[0]

    return wyrazy[0]


if __name__ == "__main__":
    print("Sprawdzanie funkcji fibonnacci...")
    sprawdz(wynik=fibonacci(-9), oczekiwany=None)
    sprawdz(wynik=fibonacci(-1), oczekiwany=None)
    sprawdz(wynik=fibonacci(0), oczekiwany=0)
    sprawdz(wynik=fibonacci(1), oczekiwany=1)
    sprawdz(wynik=fibonacci(2), oczekiwany=1)
    sprawdz(wynik=fibonacci(3), oczekiwany=2)
    sprawdz(wynik=fibonacci(6), oczekiwany=8)
    sprawdz(wynik=fibonacci(100), oczekiwany=354224848179261915075)
    print("Sprawdzanie funkcji fibonnacci... Ok.")
