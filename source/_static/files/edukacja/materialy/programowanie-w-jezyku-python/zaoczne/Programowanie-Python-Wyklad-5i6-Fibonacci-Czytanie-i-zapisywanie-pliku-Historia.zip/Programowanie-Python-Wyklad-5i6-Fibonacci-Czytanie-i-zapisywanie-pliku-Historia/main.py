# from fibbonacci import fibonacci
# używamy funkcji w 'zwykły' sposób:
# fibonacci(x)

import fibonacci
# używamy funkcji podając nazwę modułu
# fibonacci.fibonacci(x)

import os.path


def wyswietl_historie(nazwa_pliku):
    # sprawdzamy czy plik istnieje
    if os.path.isfile(nazwa_pliku):
        # otwieramy plik w trybie do odczytu
        with open(nazwa_pliku, "r") as fp:
            print("Ostatnio liczone wyrazy:")

            # odczytujemy linia po linii
            for linia in fp:
                # odczytane linie zawierają znak nowej linii
                # chcemy go usunać, dlatego używamy funkcji strip
                # strip usunie białe znaki z początku i z końca napisu
                print(linia.strip())


def dopisz_do_historii(nazwa_pliku, numer_wyrazu):
    # otwieramy plik w trybie do dopisywania
    with open(nazwa_pliku, "a") as fp:
        # przygotowujemy linię do zapisu
        # każda linia składa się z liczby i znaku nowej linii
        linia = f"{numer_wyrazu}\n"
        # zapisujemy linię do pliku
        fp.write(linia)


def main():
    nazwa_pliku = "history.txt"

    wyswietl_historie(nazwa_pliku)

    numer_wyrazu = int(input("Podaj numer wyrazu: "))

    dopisz_do_historii(nazwa_pliku, numer_wyrazu)

    wynik = fibonacci.fibonacci(numer_wyrazu)
    print("Wynik:", wynik)


if __name__ == "__main__":
    main()
