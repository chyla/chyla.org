#!/usr/bin/env python3

import sys
from PyPDF2 import PdfMerger


def usage(script_name):
    print("Usage:", script_name, "OUTPUT_FILE.pdf INPUT_FILE.pdf [INPUT_FILE.pdf]...")


def main():
    if len(sys.argv) < 3:
        usage(sys.argv[0])
        return

    output_file = sys.argv[1]
    input_files = sys.argv[2:]

    try:
        merger = PdfMerger()

        for pdf in input_files:
            merger.append(pdf)

        merger.write(output_file)
        merger.close()
    except FileNotFoundError as e:
        print(e)
    except Exception as e:
        print("Unexpected error:", e)


if __name__ == "__main__":
    main()
