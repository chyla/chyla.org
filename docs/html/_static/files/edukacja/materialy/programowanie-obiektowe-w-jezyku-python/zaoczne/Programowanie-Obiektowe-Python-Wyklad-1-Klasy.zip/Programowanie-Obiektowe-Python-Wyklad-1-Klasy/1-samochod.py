s1_kolor = "czerwony"
s1_marka = "fiat"

s2_kolor = "czarny"
s2_marka = "bmw"


def run(kolor, marka):
    ...
    print("Wszystko gotowe, jedziemy {} {}".format(kolor, marka))


run(s1_kolor, s1_marka)
run(s1_kolor, s2_marka)
