# PEP8

class Samochod:
    def __init__(self, kolor, marka):
        self.kolor = kolor
        self.marka = marka
        self._paliwo = 0  # PEP8

    def zatankuj(self):
        if self._paliwo > 90:
            print("Nie tankujemy wiecej")
        else:
            self._paliwo += 10

    def run(self):
        print("Stan paliwa:", self._paliwo)
        if self._czy_mamy_paliwo():
            print(
                "Wszystko gotowe, jedziemy {} {}".format(
                    self.kolor, self.marka
                )
            )
        else:
            print("Za malo paliwa")

class SamochodBenzyna(Samochod):
    def __str__(self):
        text = "Samochod {} {}, stan paliwa: {}".format(
            self.kolor, self.marka, self._paliwo
        )
        return text

    def _czy_mamy_paliwo(self):
        return self._paliwo > 15


class SamochodLpg(Samochod):
    def __str__(self):
        text = "Samochod {} {}, stan paliwa: {}".format(
            self.kolor, self.marka, self._paliwo
        )
        return text

    def _czy_mamy_paliwo(self):
        return self._paliwo > 30


class SamochodElek(Samochod):
    def zatankuj(self):
        if self._paliwo > 90:
            print("Nie tankujemy wiecej")
        else:
            self._paliwo += 5

    def _czy_mamy_paliwo(self):
        return self._paliwo > 15

s1 = SamochodBenzyna("czerwony", "fiat")
s2 = SamochodLpg("czarny", "bmw")
s3 = SamochodElek("czarny", "bmw elek")

s1.zatankuj()
s2.zatankuj()
s3.zatankuj()

s1.zatankuj()
s2.zatankuj()
s3.zatankuj()

s1.zatankuj()
s2.zatankuj()
s3.zatankuj()

s1.run()
s2.run()
s3.run()
