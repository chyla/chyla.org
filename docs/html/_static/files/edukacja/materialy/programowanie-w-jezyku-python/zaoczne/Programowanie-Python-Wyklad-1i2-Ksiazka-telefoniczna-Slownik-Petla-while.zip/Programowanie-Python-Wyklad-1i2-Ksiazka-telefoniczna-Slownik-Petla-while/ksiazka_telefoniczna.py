#
# Prosta ksiazka telefoniczna
#
# 1. wypisanie zawartosci
# 2. dodanie nowego wpisu
# 3. koniec
# wybor (1/2/3): 1
# Adam - 123456789
# Jan - 45678933
# Alicja - 1423734
# 1. wypisanie zawartosci
# 2. dodanie nowego wpisu
# 3. koniec
# wybor (1/2/3): 2
# imie: ...
# tel: ...
# 1. wypisanie zawartosci
# 2. dodanie nowego wpisu
# 3. koniec
# wybor (1/2/3): 3

ksiazka = {}

czy_dzialac = True
while czy_dzialac:
    print("""
1. wypisanie zawartosci
2. dodanie nowego wpisu
3. koniec
""")
    wybor = input("wybor (1/2/3): ") # 2

    if wybor == "1":
        for imie in ksiazka:
            telefon = ksiazka[imie]
            print(imie, '-', telefon)
    elif wybor == "2":
        imie = input("imie: ")
        telefon = input("telefon: ")

        ksiazka[imie] = telefon
    elif wybor == "3":
        czy_dzialac = False
    else:
        print("Wybrano bledna opcje")