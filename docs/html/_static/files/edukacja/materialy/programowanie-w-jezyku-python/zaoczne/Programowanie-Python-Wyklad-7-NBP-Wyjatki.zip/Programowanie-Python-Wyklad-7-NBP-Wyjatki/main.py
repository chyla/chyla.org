# pip install pymsgbox
from pymsgbox import prompt, alert

# pip install requests
import requests

NBP_JSON_PATTERN = 'http://api.nbp.pl/api/exchangerates/rates/A/{}/{}/?format=json'


class CancelException(Exception):
    pass


class NbpNoDataException(Exception):
    pass


def pobierz_walute_od_uzytkownika():
    waluta = prompt(text="Podaj walutę:", title='Kurs walut')
    if waluta is None:
        raise CancelException
    return waluta


def pobierz_date_od_uzytkownika():
    data = prompt(text="Podaj date (format RRRR-MM-DD):",
                  title='Kurs walut')
    if data is None:
        raise CancelException
    return data


def pobierz_kurs_z_nbp(waluta, data):
    response = requests.get(NBP_JSON_PATTERN.format(waluta, data))
    if response.ok:
        dane = response.json()
        kurs = dane["rates"][0]["mid"]
        return kurs
    else:
        raise NbpNoDataException


def main():
    try:
        waluta = pobierz_walute_od_uzytkownika()
        data = pobierz_date_od_uzytkownika()

        kurs = pobierz_kurs_z_nbp(waluta, data)

        alert(text=f'Kurs sredni dla {waluta} w dniu {data}: {kurs} PLN')
    except CancelException:
        pass
    except NbpNoDataException:
        alert(text="Brak danych.")
    except Exception as e:
        alert(text=f'Wystąpił błąd! {e}', title='Kurs walut')


if __name__ == "__main__":
    main()
