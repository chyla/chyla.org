# TDD --> Test Driven Development
# 1. szablon funkcji - pusta funkcja
# 2. napisalismy test
# 3. uruchomilismy skrypt --> uruchomily sie testy
# 4. nic nie dziala
# 5. poprawilismy funkcje
# 6. uruchomilismy skrypt
# 7. cos juz dziala
# 8. napisalismy kolejny test
# 9. nic nie dziala
# 10. poprawilismy funkcje
# 11. uruchomilismy testy
# 12. cos juz dziala
# 13. napisac test

# fibonacci
# 0 1 1 2 3 5 8 ...
# 0 1 2 3 4 5 6
def sprawdz(wartosc, oczekujemy):
    # assert przerywa dzialanie programu,
    # gdy warunek nie jest spelniony (jest False)
    # gdy warunek jest spelniony (True), assert nic nie robi
    assert wartosc == oczekujemy, ("Oczekiwano: " + str(oczekujemy)
                                   + "; otrzymano: " + str(wartosc))


def fibonacci(n, **kwargs):
    wyrazy = [0, 1]

    for i in range(0, n):
        kolejny_wyraz = sum(wyrazy)
        wyrazy.append(kolejny_wyraz)
        del(wyrazy[0])

    return wyrazy[0]


def fibonacci_rekurencyjnie(n, cache):
    #print("wywolano z n =", n)
    if n in cache:
        return cache[n]

    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        wyraz_n = fibonacci_rekurencyjnie(n-1, cache) + fibonacci_rekurencyjnie(n-2, cache)
        cache[n] = wyraz_n
        return wyraz_n


sprawdz(fibonacci(0, cache={}), 0)
sprawdz(fibonacci(1, cache={}), 1)
sprawdz(fibonacci(2, cache={}), 1)
sprawdz(fibonacci(3, cache={}), 2)
sprawdz(fibonacci(6, cache={}), 8)

'''
# test sprawdzajacy dzialanie cache
cache = {
    8: 3,
    9: 2
}
sprawdz(fibonacci(10, cache), 5)
'''

if __name__ == "__main__": # czy skrypt uruchomil uzytkownik?
    print("Hello FIBONACCI")
