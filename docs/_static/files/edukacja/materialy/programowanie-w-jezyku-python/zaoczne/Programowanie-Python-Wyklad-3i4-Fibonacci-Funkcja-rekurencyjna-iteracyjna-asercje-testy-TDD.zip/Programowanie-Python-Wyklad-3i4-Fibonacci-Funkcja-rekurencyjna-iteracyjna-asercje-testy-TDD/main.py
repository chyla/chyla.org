# from fibbonacci import fibonacci, fibonacci_rekurencyjnie
# używamy funkcji w 'zwykły' sposób:
# fibonacci(x, cache=cache)


import fibonacci as fib
# używamy funkcji podając nazwę modułu
# fib.fibonacci(x, cache=cache)

def main():
    cache = {}
    x = int(input("Podaj numer elementu: "))

    wyraz = fib.fibonacci(x, cache=cache)
    print(wyraz)

    wyraz = fib.fibonacci_rekurencyjnie(x, cache=cache)
    print(wyraz)


main()
