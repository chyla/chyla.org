class tetranacci:
    def __init__(self, steps):
        self.steps = steps
        self.numbers = [0, 0, 0, 1]
        self.count = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self.count == self.steps:
            raise StopIteration
        else:
            current = self.numbers[0]

            next_element = sum(self.numbers)
            self.numbers.append(next_element)
            del(self.numbers[0])

            self.count += 1
            return current

# 0, 0, 0, 1, 1, 2, 4, 8, ...
for i, x in enumerate(tetranacci(10), start=1):
    print(f"{i}: {x}")
