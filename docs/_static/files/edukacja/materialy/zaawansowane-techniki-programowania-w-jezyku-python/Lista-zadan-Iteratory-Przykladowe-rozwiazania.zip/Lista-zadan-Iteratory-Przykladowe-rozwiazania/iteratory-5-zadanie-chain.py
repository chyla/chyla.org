#!/bin/python3

class chain:
    def __init__(self, *args):
        self.args = args
        self.iters = [iter(x) for x in args]
        self.current_iter = self.iters.pop(0)

    def __iter__(self):
        return self

    def __next__(self):
        try:
            return next(self.current_iter)
        except StopIteration:
            if len(self.iters) > 0:
                self.current_iter = self.iters.pop(0)
                return self.__next__()
            else:
                raise StopIteration

for element in chain("ABC", [1, 2, 3], [], "DEF"):
    print(element, end=" ")
