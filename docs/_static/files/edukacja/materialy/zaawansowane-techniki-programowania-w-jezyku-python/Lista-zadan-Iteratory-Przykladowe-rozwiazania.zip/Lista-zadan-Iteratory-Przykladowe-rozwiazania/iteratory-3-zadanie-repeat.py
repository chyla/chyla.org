class repeat:
    def __init__(self, value, times):
        self.value = value
        self.times = times
        self.count = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self.count < self.times:
            self.count += 1
            return self.value
        else:
            raise StopIteration


for i in repeat(10, 5):
    print("repeat:", i)
