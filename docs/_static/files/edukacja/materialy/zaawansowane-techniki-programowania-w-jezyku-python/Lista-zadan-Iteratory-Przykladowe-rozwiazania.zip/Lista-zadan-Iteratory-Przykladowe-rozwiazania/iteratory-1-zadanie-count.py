from itertools import islice

class count:
    def __init__(self, start = 0):
        self._ctr = start

    def __iter__(self):
        return self

    def __next__(self):
        val = self._ctr
        self._ctr += 1
        return val

count_it = count(5)

for x in islice(count_it, 0, 6): # --> 5, 6, 7, 8, 9, 10
    print(x)
