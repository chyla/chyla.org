import multiprocessing
import os


def subprocess():
    print("PID potomka:", os.getpid())


def main():
    print("PID rodzica:", os.getpid())

    processes = [
        multiprocessing.Process(target=subprocess),
        multiprocessing.Process(target=subprocess),
    ]

    for p in processes:
        p.start()

    for p in processes:
        p.join()


if __name__ == "__main__":
    main()
