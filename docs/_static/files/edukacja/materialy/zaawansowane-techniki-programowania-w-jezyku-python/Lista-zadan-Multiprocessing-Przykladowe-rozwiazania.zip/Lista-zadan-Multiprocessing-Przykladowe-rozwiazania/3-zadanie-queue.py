import multiprocessing
import time


def subprocess(queue):
    should_work = True
    while should_work:
        item = queue.get()
        print("Proces potomny:", item)
        if item == 'exit':
            should_work = False


def main():
    queue = multiprocessing.Queue()
    child = multiprocessing.Process(target=subprocess, args=(queue,))

    child.start()

    should_work = True
    while should_work:
        time.sleep(1)
        text = input("Podaj napis: ").strip()
        queue.put(text)
        if text == 'exit':
            should_work = False

    child.join()


if __name__ == "__main__":
    main()
