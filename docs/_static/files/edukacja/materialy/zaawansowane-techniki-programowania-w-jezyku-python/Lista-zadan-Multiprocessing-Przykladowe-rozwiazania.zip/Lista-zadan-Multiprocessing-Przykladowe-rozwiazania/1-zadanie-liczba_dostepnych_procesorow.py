import multiprocessing


def main():
    cpus = multiprocessing.cpu_count()

    print(f"cpus: {cpus}")


if __name__ == "__main__":
    main()
