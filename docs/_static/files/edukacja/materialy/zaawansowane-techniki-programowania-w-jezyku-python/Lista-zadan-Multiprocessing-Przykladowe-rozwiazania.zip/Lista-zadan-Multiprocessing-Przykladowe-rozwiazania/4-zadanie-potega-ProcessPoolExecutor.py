from concurrent.futures import ProcessPoolExecutor


def power(n):
    return n * n


def main():
    user_text = input("Podaj liczby: ")
    input_data = [int(x) for x in user_text.split()]

    with ProcessPoolExecutor(max_workers=3) as pool:
        output_data = pool.map(power, input_data)

    str_output = [str(x) for x in output_data]
    print("Wyniki:", ' '.join(str_output))


if __name__ == "__main__":
    main()
