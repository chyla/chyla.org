def main():
    print('czesc!')
