from .hello import main

main()
