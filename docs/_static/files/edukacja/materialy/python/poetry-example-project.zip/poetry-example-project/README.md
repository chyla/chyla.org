plhelloprinter
==============

Przykladowa aplikacja zlozona z kilku plikow, gotowa do zbudowania
i potencjalnej publikacji w repozytorium PyPi.

Konfiguracja Poetry z komentarzami w pliku pyproject.toml.

Wpisz w konsoli ponizsze polecenie, by uruchomic projekt:

  poetry run python -m src.plhelloprinter

Wpisz w konsoli ponizsze polecenie, by uruchomic testy:

  poetry run pytest

Przydatne polecenia Poetry:

- poetry list - wpisanie wszystkich dostepnych polecen wraz z ich opisem
- poetry add PAKIET - dodanie zaleznosci i instalacja w wirtualnym srodowisku
- poetry add --dev PAKIET - dodanie zaleznosci programistycznej i instalacja w wirtualnym srodowisku
- poetry update - aktualizacja zaleznosci
- poetry run CMD  - uruchomienie polecenia CMD w wirtualnym srodowisku np: poetry run pytyest
- poetry build - zbudowanie pakietu dystrybucyjnego
- poetry publish - publikacja pakietu dystrybucyjnego w repozytorium PyPi
- poetry install - instaluje zaleznosci i projekt w wirtualnym srodowisku
