from plhelloprinter.text import hello_text

def test_text():
    assert hello_text == 'czesc'
