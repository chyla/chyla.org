hello_text = 'czesc'
