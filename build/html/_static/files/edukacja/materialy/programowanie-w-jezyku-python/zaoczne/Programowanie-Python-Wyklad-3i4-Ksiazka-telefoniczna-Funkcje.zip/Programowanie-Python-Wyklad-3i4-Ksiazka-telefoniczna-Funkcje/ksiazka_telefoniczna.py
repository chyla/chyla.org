# 1. wypisanie zawartosci
# 2. dodanie nowego wpisu
# 3. koniec
# wybor (1/2/3): 1
# Adam - 123456789
# Jan - 45678933
# Alicja - 1423734
# 1. wypisanie zawartosci
# 2. dodanie nowego wpisu
# 3. koniec
# wybor (1/2/3): 2
# imie: ...
# tel: ...
# 1. wypisanie zawartosci
# 2. dodanie nowego wpisu
# 3. koniec
# wybor (1/2/3): 3


def czy_zawiera_jakies_osoby(ksiazka_telefoniczna):
    return len(ksiazka_telefoniczna)


def wypisz_zawartosc(ksiazka_telefoniczna):
    if czy_zawiera_jakies_osoby(ksiazka_telefoniczna):
        for imie in ksiazka_telefoniczna:
            telefon = ksiazka_telefoniczna[imie]
            print(imie, '-', telefon)
    else:
        print("Brak osob w ksiazce tel.")


def dodaj_nowa_osobe(ksiazka_telefoniczna):
    imie = input("imie: ")
    telefon = input("telefon: ")

    ksiazka_telefoniczna[imie] = telefon

def main():
    ksiazka = {}

    czy_dzialac = True
    while czy_dzialac:
        print("""
    1. wypisanie zawartosci
    2. dodanie nowego wpisu
    3. koniec
    """)
        wybor = input("wybor (1/2/3): ")

        if wybor == "1":
            wypisz_zawartosc(ksiazka)
        elif wybor == "2":
            dodaj_nowa_osobe(ksiazka)
        elif wybor == "3":
            czy_dzialac = False
        else:
            print("Wybrano bledna opcje")

main()
